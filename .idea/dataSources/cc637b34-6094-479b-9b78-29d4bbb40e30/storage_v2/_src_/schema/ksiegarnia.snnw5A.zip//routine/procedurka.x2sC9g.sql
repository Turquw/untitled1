create
    definer = root@localhost procedure procedurka(IN dni int)
BEGIN 
TRUNCATE TABLE procedura;
INSERT INTO procedura(`id_ksiazki`,`tytul`,`autor`,`kategoria`,`data_wypozyczenia`,`imie`,`nazwisko`) SELECT ksiazka.id_ksiazki,`tytul`,`autor`,`kategoria`,wypozyczone_i_w_trakcie.data_wypozyczenia,czytelnik.imie,czytelnik.nazwisko FROM `ksiazka`LEFT JOIN wypozyczone_i_w_trakcie on ksiazka.id_ksiazki=wypozyczone_i_w_trakcie.id_ksiazki LEFT join czytelnik on wypozyczone_i_w_trakcie.id_czytelnika=czytelnik.id_klient WHERE `data_wypozyczenia`>DATE_SUB(CURRENT_DATE,INTERVAL dni DAY) and wypozyczone_i_w_trakcie.stan=2; 
END;

