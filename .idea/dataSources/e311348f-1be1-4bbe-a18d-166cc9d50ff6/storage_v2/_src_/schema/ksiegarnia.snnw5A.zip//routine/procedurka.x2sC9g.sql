create
    definer = root@localhost procedure procedurka(IN dni int)
BEGIN 
TRUNCATE TABLE procedura;
INSERT INTO procedura(`id_ksiazki`,`tytul`,`autor`,`kategoria`,`data_wypozyczenia`) SELECT `id_ksiazki`,`tytul`,`autor`,`kategoria`,`data_wypozyczenia` FROM `ksiazka` WHERE `data_wypozyczenia`>DATE_SUB(CURRENT_DATE,INTERVAL dni DAY); 
END;

