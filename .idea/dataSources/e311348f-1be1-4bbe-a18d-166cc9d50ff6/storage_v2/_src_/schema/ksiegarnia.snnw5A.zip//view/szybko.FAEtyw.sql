create definer = root@localhost view szybko as
select `k`.`tytul` AS `tytul`, `k`.`autor` AS `autor`, `w`.`nazwa` AS `nazwa`
from (`ksiegarnia`.`ksiazka` `k` left join `ksiegarnia`.`wydawnictwo` `w`
      on (`k`.`id_wtdawnictwa_FK` = `w`.`id_wydawnictwa`))
where `k`.`tytul` like '%a';

