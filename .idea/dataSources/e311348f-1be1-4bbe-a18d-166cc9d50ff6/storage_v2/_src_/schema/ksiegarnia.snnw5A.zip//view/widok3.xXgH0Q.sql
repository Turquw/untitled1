create definer = root@localhost view widok3 as
select `p`.`id_wypozyczalni_FK` AS `id_wypozyczalni_FK`,
       `p`.`imie`               AS `imie`,
       `p`.`nazwisko`           AS `nazwisko`,
       `w`.`id_wypozyczalni`    AS `id_wypozyczalni`,
       `w`.`miasto`             AS `miasto`,
       `w`.`ulica`              AS `ulica`
from (`ksiegarnia`.`pracownicy` `p` join `ksiegarnia`.`wypozyczalnia` `w`
      on (`p`.`id_wypozyczalni_FK` = `w`.`id_wypozyczalni`))
where `p`.`imie` like '%a';

