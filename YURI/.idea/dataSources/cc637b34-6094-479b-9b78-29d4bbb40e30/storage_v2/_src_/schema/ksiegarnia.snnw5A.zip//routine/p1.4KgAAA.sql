create
    definer = root@localhost procedure p1()
SELECT * FROM czytelnik;

