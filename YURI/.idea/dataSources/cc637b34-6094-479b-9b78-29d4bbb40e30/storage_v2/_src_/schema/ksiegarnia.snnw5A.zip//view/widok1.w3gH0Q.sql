create definer = root@localhost view widok1 as
select `k`.`id_ksiazki`    AS `id_ksiazki`,
       `k`.`tytul`         AS `tytul`,
       `k`.`autor`         AS `autor`,
       `k`.`ilosc`         AS `ilosc`,
       `c`.`imie`          AS `imie`,
       `c`.`nazwisko`      AS `nazwisko`,
       `c`.`id_ksiazki_FK` AS `id_ksiazki_FK`
from (`ksiegarnia`.`ksiazka` `k` join `ksiegarnia`.`czytelnik` `c` on (`k`.`id_ksiazki` = `c`.`id_ksiazki_FK`))
where `k`.`ilosc` = 10;

